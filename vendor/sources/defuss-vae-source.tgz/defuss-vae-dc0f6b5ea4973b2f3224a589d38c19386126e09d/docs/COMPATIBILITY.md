# Compatibility

| Host | Skills | Forced hooks | Notes |
|---|---:|---:|---|
| Claude Code | VERIFIED | VERIFIED | `plugin/.claude-plugin/plugin.json` + auto-loaded `plugin/hooks/hooks.json`; Stop blocks once per turn, the agent loops `vae.py gate` in-turn. |
| Codex plugin runtime | VERIFIED | HYPOTHESIS | Portable + legacy Codex manifests included; hook trust required. Stop `decision: "block"` parity with Claude Code is untested. |
| GitHub Copilot CLI / other plugin hosts accepting Claude-style packages | HYPOTHESIS | UNKNOWN | Skills are portable; lifecycle-hook parity depends on host version. |
| Generic Agent Skills hosts (Cursor/Gemini/etc.) | VERIFIED structure | UNKNOWN | Copy `plugin/skills/`; run `python3 plugin/scripts/vae.py gate --repo .` manually; `${CLAUDE_PLUGIN_ROOT}` is not substituted there (plugin root = skill dir/../..). |

## Python

`VERIFIED:` the unit suite (including the hook adapter run as a subprocess) passes on Python 3.8, 3.9, 3.10 (uv-managed) and 3.14, and the gate ran end to end under Apple's `/usr/bin/python3` 3.9.6. `make compat` keeps 3.9, the macOS Command Line Tools version, tested.

Hooks run on plain `python3`, not `uv run`. `VERIFIED:` `uv run` adds 5.4 ms (+17%) to a hook that fires before every Bash call, and a hook command that cannot start (uv missing) is a non-blocking error in Claude Code, i.e. fail-open. uv belongs in tooling (`make setup|compat|coverage|lint`), not in the enforcement path.

## Stop-hook semantics

`VERIFIED:` Claude Code hooks reference (checked 2026-10-05): Stop `decision: "block"` + `reason` and `hookSpecificOutput.additionalContext` both continue the turn, under one shared cap (8 consecutive continuations, then the turn ends). So the hook blocks only while `stop_hook_active` is false, and otherwise returns just a user-facing `systemMessage`. Before this, answering `stop_hook_active` with `additionalContext` (the 2026-09-30 reading said that ended the turn) looped the model up to the cap whenever the gate waited on a human; hook strings over 10,000 characters are replaced by a file path plus a 2,000-character preview. Gate text is capped well below that.

## Template Makefile process groups

`VERIFIED:` macOS `/bin/sh` (bash 3.2): `set -m` puts the background service in its own process group and `kill -s TERM -- -PGID` reaps grandchildren (`MakefileTemplateTests`, e2e `service.lifecycle`).

`VERIFIED:` `dash` refuses `set -m` without a tty ("can't access tty; job control turned off"), so the template prefers `setsid` when available.

`HYPOTHESIS:` Linux with util-linux or busybox `setsid` gives the same group semantics. Falsifier: the `ubuntu-latest` job of `.github/workflows/verify.yml`, whose `make test` runs the template test on whichever branch the platform takes; `UNKNOWN` until that workflow has run on GitHub.

## WHY two Codex hook declarations?

`VERIFIED:` OpenAI's Codex plugin docs ([Package your plugin](https://developers.openai.com/codex/plugins/build), checked 2026-10-19) make `extensions.com.openai` in the root `plugin.json` the source of OpenAI settings: hooks, presentation (`interface`), apps. `.codex-plugin/plugin.json` is a compatibility fallback, read only when that object is absent, and the two are never merged. Codex sets `CLAUDE_PLUGIN_ROOT` for plugin hooks, so `hooks/hooks.json` runs unchanged ([Hooks](https://learn.chatgpt.com/docs/hooks)).

`VERIFIED:` (the human's report, 2026-10-19) a Codex build ignored the hooks of `.codex-plugin/plugin.json` while the root manifest existed without the extension, so defuss-vae ran without its gate there. `UNKNOWN:` which Codex version that was.

Therefore the root manifest declares the hooks and the presentation under `extensions.com.openai`, and the overlay keeps the same values for builds that read only the fallback. `test_codex_finds_the_hooks_in_the_root_manifest` keeps both equal. The rejected alternative, deleting the overlay, would drop every build that still reads only `.codex-plugin/plugin.json`.

## Swarm registry

`vae.py swarm` needs a POSIX host. `VERIFIED:` (`tests/test_swarm.py`, macOS) `fcntl.flock` serializes writers, `ps -A -o pid=,ppid=,stat=,lstart=` gives the process table with start times, and `start_new_session` detaches a spawned job into its own session and process group. `HYPOTHESIS:` Linux with procps behaves the same, since procps prints `lstart` in the same format under `LC_ALL=C`; falsifier: the `ubuntu-latest` CI job running `tests/test_swarm.py`. busybox `ps` has no `lstart`: liveness then falls back to `kill(pid, 0)` without pid-reuse detection, and ownership to the caller and its parent. `UNKNOWN:` Windows, which has neither `flock` nor `ps`.

An entry's pid is meaningful only on its own host: `status` reports entries from another host as `UNKNOWN` instead of judging them. A sub-agent that runs inside its harness's process (Claude Code's Agent tool) has no pid of its own, so its entry names the harness process and shares its liveness.
